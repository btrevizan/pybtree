# pybtree
An on-disk BTree implementation in Python 3.
